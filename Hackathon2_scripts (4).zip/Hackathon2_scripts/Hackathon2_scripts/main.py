#!/usr/bin/env python3
"""
Main entry point for the Space Station Safety Equipment Detection System
"""

import sys
from pathlib import Path

def main():
    # Add src to Python path
    src_path = Path(__file__).parent / "src"
    sys.path.insert(0, str(src_path))
    
    if len(sys.argv) < 2:
        print("Usage: python main.py [mode] [options]")
        print("Modes: train, detect, camera, mobile, visualize")
        return
    
    mode = sys.argv[1]
    
    if mode == 'train':
        import subprocess
        cmd = [sys.executable, str(Path(__file__).parent / "src" / "training" / "train.py")]
        subprocess.run(cmd)
        
    elif mode == 'detect':
        if len(sys.argv) < 3:
            print("Error: Image path required for detection mode")
            print("Usage: python main.py detect path/to/image.jpg")
            return
        import subprocess
        cmd = [sys.executable, str(Path(__file__).parent / "src" / "detection" / "predict.py"), "--image", sys.argv[2]]
        subprocess.run(cmd)
        
    elif mode == 'camera':
        import subprocess
        cmd = [sys.executable, str(Path(__file__).parent / "src" / "detection" / "camera_detection.py")]
        subprocess.run(cmd)
        
    elif mode == 'mobile':
        import subprocess
        cmd = [sys.executable, str(Path(__file__).parent / "src" / "detection" / "mobile_app.py")]
        subprocess.run(cmd)
        
    elif mode == 'visualize':
        import subprocess
        cmd = [sys.executable, str(Path(__file__).parent / "src" / "visualization" / "visualize.py")]
        subprocess.run(cmd)
        
    else:
        print(f"Unknown mode: {mode}")
        print("Available modes: train, detect, camera, mobile, visualize")

if __name__ == "__main__":
    main()