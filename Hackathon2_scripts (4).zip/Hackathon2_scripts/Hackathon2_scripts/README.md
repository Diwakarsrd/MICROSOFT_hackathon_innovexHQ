# Space Station Safety Object Detection

This project implements a YOLO-based object detection system to identify 7 safety equipment items in a space station environment.

## Safety Equipment Classes
1. OxygenTank
2. NitrogenTank
3. FirstAidBox
4. FireAlarm
5. SafetySwitchPanel
6. EmergencyPhone
7. FireExtinguisher

## Setup

1. **Environment Setup**:
   ```bash
   # Run the setup scripts in order
   ENV_SETUP\create_env.bat
   ENV_SETUP\install_packages.bat
   ENV_SETUP\setup_env.bat
   ```

2. **Activate Environment**:
   ```bash
   conda activate EDU
   ```

## Usage

### Training
To train the model:
```bash
python train.py
```

### Prediction
To run predictions on test images:
```bash
python predict.py
```

To calculate metrics only (if predictions already exist):
```bash
python predict.py --metrics-only
```

### Viewing Predictions
To view random predictions:
```bash
python view_predictions.py
```

## Output

All output files are generated in the `predictions/` directory:
- `images/`: Test images with bounding box annotations
- `labels/`: YOLO format label files with bounding box coordinates

## Results

The model achieves the following performance on the test set:
- **mAP@0.5**: 0.2672
- **mAP@0.5:0.95**: 0.1902
- **Precision**: 0.433
- **Recall**: 0.283

See `FINAL_PROJECT_SUMMARY.md` for detailed results and `PREDICTION_SUMMARY.md` for a concise overview.

## Project Structure
```
Hackathon2_scripts/
├── ENV_SETUP/              # Environment setup scripts
├── hackathon2_train_1/     # Training dataset
├── hackathon2_test3/       # Test dataset
├── predictions/            # Prediction outputs
├── runs/                   # Training and validation results
├── train.py               # Training script
├── predict.py             # Prediction script
├── view_predictions.py    # Script to view predictions
├── visualize.py           # Data visualization script
├── mobile_app.py          # Mobile app interface
├── yolo_params.yaml       # YOLO configuration
├── classes.txt            # Class names
├── requirements.txt       # Python dependencies
├── README.md              # This file
├── PROJECT_SUMMARY.md     # Project overview
├── PREDICTION_SUMMARY.md  # Prediction results summary
└── FINAL_PROJECT_SUMMARY.md # Detailed project summary
```