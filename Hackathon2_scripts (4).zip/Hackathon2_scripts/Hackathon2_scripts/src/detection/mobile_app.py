"""
Mobile Application for Space Station Safety Equipment Detection

This script demonstrates how the trained YOLO model can be integrated into a mobile application
for real-time safety equipment detection in a space station environment.
"""

# Conditional imports
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    cv2 = None
    CV2_AVAILABLE = False
    print("Warning: OpenCV (cv2) not installed. Some features may not work.")

try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except ImportError:
    YOLO = None
    ULTRALYTICS_AVAILABLE = False
    print("Warning: ultralytics not installed. Some features may not work.")

import torch
import numpy as np
import time
from datetime import datetime
import json
import os
from pathlib import Path

class SpaceStationSafetyApp:
    def __init__(self, model_path=None):
        """
        Initialize the mobile application with the trained YOLO model
        """
        self.model = None
        
        # Determine the correct model path
        if model_path is None:
            # Look for model in project runs directory
            project_root = Path(__file__).parent.parent.parent
            possible_paths = [
                project_root / "runs" / "detect" / "train" / "weights" / "best.pt",
                project_root / "runs" / "detect" / "train1" / "weights" / "best.pt",
                project_root / "yolov8s.pt",
                Path(__file__).parent / "runs" / "detect" / "train" / "weights" / "best.pt"
            ]
            
            for path in possible_paths:
                if path.exists():
                    model_path = path
                    break
        
        if not ULTRALYTICS_AVAILABLE:
            print("YOLO functionality not available due to missing ultralytics package")
            return
            
        # Load model with error handling
        if model_path and Path(model_path).exists():
            try:
                self.model = YOLO(str(model_path)) if YOLO else None
                print(f"Model loaded successfully from {model_path}")
            except Exception as e:
                print(f"Error loading model from {model_path}: {e}")
        else:
            # Try alternative model paths
            project_root = Path(__file__).parent.parent.parent
            alternative_paths = [
                project_root / "yolov8s.pt",
                project_root / "runs" / "detect" / "train1" / "weights" / "best.pt",
                "yolov8s.pt"
            ]
            model_loaded = False
            for alt_path in alternative_paths:
                try:
                    if Path(alt_path).exists() and YOLO:
                        self.model = YOLO(str(alt_path))
                        print(f"Model loaded successfully from alternative path: {alt_path}")
                        model_loaded = True
                        break
                except Exception as alt_e:
                    print(f"Failed to load model from {alt_path}: {alt_e}")
                    continue
            
            if not model_loaded:
                print("Could not load any model. Please check model paths.")

    def _safe_cv2_call(self, func_name, *args, **kwargs):
        """Safely call cv2 functions with error handling"""
        if not CV2_AVAILABLE or cv2 is None:
            return None
        try:
            func = getattr(cv2, func_name)
            return func(*args, **kwargs)
        except AttributeError:
            print(f"cv2.{func_name} not available")
            return None
        except Exception as e:
            print(f"Error calling cv2.{func_name}: {e}")
            return None
    
    def detect_equipment(self, image, confidence_threshold=0.5):
        """
        Detect safety equipment in the provided image
        """
        if not ULTRALYTICS_AVAILABLE or self.model is None:
            # Return mock results object
            return type('Results', (), {
                'boxes': [], 
                'plot': lambda: image
            })()
            
        try:
            results = self.model.predict(image, conf=confidence_threshold, verbose=False)
            return results[0]
        except Exception as e:
            print(f"Error during detection: {e}")
            # Return empty results object
            return type('Results', (), {
                'boxes': [], 
                'plot': lambda: image
            })()
    
    def draw_detections(self, image, results):
        """
        Draw bounding boxes and labels on the image
        """
        if not ULTRALYTICS_AVAILABLE:
            return image
            
        try:
            img = results.plot()
            return img
        except Exception as e:
            print(f"Error drawing detections: {e}")
            return image
    
    def get_equipment_info(self, class_name):
        """
        Get maintenance information for a specific equipment
        """
        # Class names for the 7 safety equipment types
        self.class_names = ['OxygenTank', 'NitrogenTank', 'FirstAidBox', 'FireAlarm', 
                           'SafetySwitchPanel', 'EmergencyPhone', 'FireExtinguisher']
        
        # Equipment maintenance database (simulated)
        self.equipment_maintenance = {
            'OxygenTank': {'last_maintenance': '2025-10-15', 'next_maintenance': '2026-04-15', 'status': 'Good'},
            'NitrogenTank': {'last_maintenance': '2025-09-20', 'next_maintenance': '2026-03-20', 'status': 'Good'},
            'FirstAidBox': {'last_maintenance': '2025-11-01', 'next_maintenance': '2026-05-01', 'status': 'Good'},
            'FireAlarm': {'last_maintenance': '2025-08-05', 'next_maintenance': '2026-02-05', 'status': 'Good'},
            'SafetySwitchPanel': {'last_maintenance': '2025-10-30', 'next_maintenance': '2026-04-30', 'status': 'Good'},
            'EmergencyPhone': {'last_maintenance': '2025-09-12', 'next_maintenance': '2026-03-12', 'status': 'Good'},
            'FireExtinguisher': {'last_maintenance': '2025-11-05', 'next_maintenance': '2026-05-05', 'status': 'Good'}
        }
        
        return self.equipment_maintenance.get(class_name, {})
    
    def update_detection_history(self, detections):
        """
        Update detection history for continuous learning
        """
        if not hasattr(self, 'detection_history'):
            self.detection_history = []
            
        timestamp = datetime.now().isoformat()
        self.detection_history.append({
            'timestamp': timestamp,
            'detections': detections
        })
        
        # Keep only the last 100 detections
        if len(self.detection_history) > 100:
            self.detection_history = self.detection_history[-100:]
    
    def save_detection_report(self, filename=None):
        """
        Save detection history to a JSON file
        """
        if not hasattr(self, 'detection_history'):
            self.detection_history = []
            
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"detection_report_{timestamp}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(self.detection_history, f, indent=2)
            print(f"Detection report saved to {filename}")
            return filename
        except Exception as e:
            print(f"Error saving detection report: {e}")
            return None
    
    def simulate_falcon_integration(self):
        """
        Simulate integration with Falcon for continuous model updates
        This function would normally communicate with the Falcon API
        """
        print("Checking for updates from Falcon...")
        
        # In a real implementation, this would:
        # 1. Connect to Falcon API
        # 2. Check for new training data from the specified dataset paths:
        #    - Training data: ../hackathon2_train_1/train_1/train1/
        #    - Validation data: ../hackathon2_train_1/train_1/val1/
        #    - Test data: ../hackathon2_test3/test3/
        # 3. Trigger retraining if needed
        # 4. Download updated model weights
        
        # For simulation, we'll just print a message
        print("No updates available from Falcon at this time.")
        print("Model is up-to-date with the latest synthetic data.")
    
    def run_camera_detection(self, confidence_threshold=0.5):
        """
        Run real-time detection using the device camera
        """
        if not ULTRALYTICS_AVAILABLE or self.model is None:
            print("Camera detection not available without ultralytics package or model")
            return
            
        if not CV2_AVAILABLE or cv2 is None:
            print("Camera detection not available without OpenCV")
            return
        
        # Try different camera indices
        camera_indices = [0, 1, 2, 3]
        cap = None
        
        for idx in camera_indices:
            try:
                cap = self._safe_cv2_call('VideoCapture', idx)
                if cap and cap.isOpened():
                    print(f"Camera opened successfully at index {idx}")
                    break
                if cap:
                    self._safe_cv2_call('release', cap)
                    cap = None
            except Exception as e:
                print(f"Error opening camera at index {idx}: {e}")
                if cap:
                    self._safe_cv2_call('release', cap)
                cap = None
        
        if cap is None or not cap.isOpened():
            print("Error: Could not open any camera")
            return
        
        print("Space Station Safety Equipment Detector")
        print("Press 'q' to quit, 's' to save screenshot, 'f' to check for Falcon updates")
        
        frame_count = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Error: Could not read frame")
                continue
            
            frame_count += 1
            
            # Process every 3rd frame for better performance
            if frame_count % 3 == 0:
                # Detect equipment
                results = self.detect_equipment(frame, confidence_threshold)
                
                # Draw detections
                annotated_frame = self.draw_detections(frame, results)
                
                # Display detection count
                detection_count = len(getattr(results, 'boxes', []))
                # Using cv2.putText with proper attribute access
                font = cv2.FONT_HERSHEY_SIMPLEX if hasattr(cv2, 'FONT_HERSHEY_SIMPLEX') else 0
                if font is not None:
                    self._safe_cv2_call('putText', annotated_frame, f"Detections: {detection_count}", (10, 30), 
                                       font, 1, (0, 255, 0), 2)
                
                # Display frame count
                if font is not None:
                    self._safe_cv2_call('putText', annotated_frame, f"Frame: {frame_count}", (10, 70), 
                                       font, 0.7, (0, 255, 0), 2)
            else:
                annotated_frame = frame
            
            # Display the annotated frame
            self._safe_cv2_call('imshow', 'Space Station Safety Equipment Detector', annotated_frame)
            
            # Handle key presses
            key = 0xFF  # Default key value
            wait_key_result = self._safe_cv2_call('waitKey', 1)
            if wait_key_result is not None:
                key = wait_key_result & 0xFF
                
            if key == ord('q'):
                break
            elif key == ord('s'):
                # Save screenshot
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"safety_detection_{timestamp}.jpg"
                self._safe_cv2_call('imwrite', filename, annotated_frame)
                print(f"Screenshot saved as {filename}")
            elif key == ord('f'):
                # Check for Falcon updates
                self.simulate_falcon_integration()
        
        # Release the camera and close windows
        if cap:
            self._safe_cv2_call('release', cap)
        self._safe_cv2_call('destroyAllWindows')
    
    def process_image_file(self, image_path, confidence_threshold=0.5):
        """
        Process a single image file
        """
        if not ULTRALYTICS_AVAILABLE or self.model is None:
            print("Image processing not available without ultralytics package or model")
            return []
            
        if not CV2_AVAILABLE or cv2 is None:
            print("Image processing not available without OpenCV")
            return []
            
        # Check if file exists
        if not os.path.exists(image_path):
            print(f"Error: Image file {image_path} does not exist")
            return []
        
        # Read image
        image = self._safe_cv2_call('imread', image_path)
        if image is None:
            print(f"Error: Could not read image from {image_path}")
            return []
        
        print(f"Processing image: {image_path}")
        
        # Detect equipment
        results = self.detect_equipment(image, confidence_threshold)
        
        # Draw detections
        annotated_image = self.draw_detections(image, results)
        
        # Save annotated image
        base_name = os.path.basename(image_path)
        name_without_ext = os.path.splitext(base_name)[0]
        output_path = f"annotated_{name_without_ext}.jpg"
        self._safe_cv2_call('imwrite', output_path, annotated_image)
        print(f"Annotated image saved as {output_path}")
        
        # Print detection results
        detections = []
        boxes = getattr(results, 'boxes', [])
        if boxes and len(boxes) > 0:
            print(f"\nDetected {len(boxes)} objects:")
            # Class names for the 7 safety equipment types
            class_names = ['OxygenTank', 'NitrogenTank', 'FirstAidBox', 'FireAlarm', 
                          'SafetySwitchPanel', 'EmergencyPhone', 'FireExtinguisher']
                          
            for i, box in enumerate(boxes):
                class_id = int(box.cls[0]) if hasattr(box, 'cls') else 0
                class_name = class_names[class_id] if class_id < len(class_names) else f"Unknown({class_id})"
                confidence = float(box.conf[0]) if hasattr(box, 'conf') else 0.0
                detections.append({
                    'class': class_name,
                    'confidence': confidence
                })
                print(f"{i+1}. {class_name} with confidence {confidence:.2f}")
                
                # Get equipment info
                info = self.get_equipment_info(class_name)
                if info:
                    print(f"   Maintenance status: {info['status']}")
                    print(f"   Last maintenance: {info['last_maintenance']}")
                    print(f"   Next maintenance: {info['next_maintenance']}")
        else:
            print("No objects detected in the image")
        
        # Update detection history
        self.update_detection_history(detections)
        
        return detections

def main():
    """
    Main function to run the Space Station Safety Equipment Detection App
    """
    print("Space Station Safety Equipment Detection App")
    print("============================================")
    
    # Initialize the app
    try:
        app = SpaceStationSafetyApp()
    except Exception as e:
        print(f"Error initializing app: {e}")
        return
    
    # Check if we're running in a environment with camera access
    has_camera = False
    if CV2_AVAILABLE and cv2 is not None:
        try:
            cap = cv2.VideoCapture(0) if hasattr(cv2, 'VideoCapture') else None
            has_camera = cap.isOpened() if cap else False
            if cap:
                cap.release()
        except:
            has_camera = False
    
    while True:
        print("\nOptions:")
        print("1. Run real-time camera detection")
        print("2. Process single image file")
        print("3. Check for Falcon updates")
        print("4. Exit")
        
        choice = input("Enter your choice (1-4): ")
        
        if choice == "1":
            if has_camera and ULTRALYTICS_AVAILABLE and app.model is not None:
                confidence = input("Enter confidence threshold (0.0-1.0, default 0.5): ")
                try:
                    confidence = float(confidence)
                except ValueError:
                    confidence = 0.5
                app.run_camera_detection(confidence)
            else:
                if not has_camera:
                    print("No camera access available.")
                if not ULTRALYTICS_AVAILABLE or app.model is None:
                    print("YOLO functionality not available.")
        elif choice == "2":
            if ULTRALYTICS_AVAILABLE and app.model is not None:
                image_path = input("Enter the path to the image file: ")
                confidence = input("Enter confidence threshold (0.0-1.0, default 0.5): ")
                try:
                    confidence = float(confidence)
                except ValueError:
                    confidence = 0.5
                app.process_image_file(image_path, confidence)
            else:
                print("Image processing not available without ultralytics package or model")
        elif choice == "3":
            app.simulate_falcon_integration()
        elif choice == "4":
            # Save detection report before exiting
            if ULTRALYTICS_AVAILABLE and hasattr(app, 'detection_history'):
                app.save_detection_report()
            print("Thank you for using the Space Station Safety Equipment Detection App!")
            break
        else:
            print("Invalid choice. Please enter a number between 1-4.")

if __name__ == "__main__":
    main()