#!/usr/bin/env python3

import cv2
import yaml
from pathlib import Path
import os
from ultralytics import YOLO
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import argparse

# Function to predict and save results
def predict_and_save(model, img_path, output_path_img, output_path_txt, imgsz=640):
    # Predict
    # Reduce image size to save memory
    results = model.predict(source=str(img_path), save=False, imgsz=imgsz, conf=0.25, verbose=False)
    result = results[0]
    
    # Save labels
    with open(output_path_txt, 'w') as f:
        for box in result.boxes:
            cls_id = int(box.cls[0])
            x_center, y_center, width, height = box.xywh[0].tolist()
            f.write(f"{cls_id} {x_center} {y_center} {width} {height}\n")
    
    # Save image with bounding boxes
    # Only plot if the image is not too large to avoid memory issues
    try:
        if hasattr(result, 'orig_shape'):
            h, w = result.orig_shape[:2]
            # Skip plotting for very large images to save memory
            if h * w < 1280 * 720:  # Reduced threshold to 720p
                # Try to plot but catch any memory errors
                try:
                    img = result.plot()
                    cv2.imwrite(str(output_path_img), img)
                except Exception as plot_error:
                    print(f"Warning: Could not plot image {img_path.name}: {plot_error}")
                    # Copy original image instead
                    orig_img = cv2.imread(str(img_path))
                    if orig_img is not None:
                        cv2.imwrite(str(output_path_img), orig_img)
                    else:
                        print(f"Error: Could not read original image {img_path.name}")
            else:
                # For large images, just copy the original image without annotations
                print(f"Skipping plotting for large image {img_path.name} to save memory")
                # Copy original image instead
                orig_img = cv2.imread(str(img_path))
                if orig_img is not None:
                    cv2.imwrite(str(output_path_img), orig_img)
                else:
                    print(f"Error: Could not read original image {img_path.name}")
        else:
            # Fallback: copy original image
            orig_img = cv2.imread(str(img_path))
            if orig_img is not None:
                cv2.imwrite(str(output_path_img), orig_img)
            else:
                print(f"Error: Could not read original image {img_path.name}")
    except Exception as e:
        print(f"Warning: Could not plot image {img_path.name}: {e}")
        # Copy original image as fallback
        try:
            orig_img = cv2.imread(str(img_path))
            if orig_img is not None:
                cv2.imwrite(str(output_path_img), orig_img)
        except Exception as read_error:
            print(f"Error: Could not read/process original image {img_path.name}: {read_error}")
    
    return result

# Function to calculate mAP
def calculate_map(model, data_yaml, split="test"):
    metrics = model.val(data=data_yaml, split=split)
    return metrics

# Function to plot confusion matrix
def plot_confusion_matrix(model, data_yaml, save_path="confusion_matrix.png"):
    # Get validation results
    metrics = model.val(data=data_yaml, split="test")
    
    # Plot confusion matrix
    cm = metrics.confusion_matrix.matrix
    if cm is not None:
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='g', cmap='Blues')
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted Labels')
        plt.ylabel('True Labels')
        plt.savefig(save_path)
        plt.close()
        print(f"Confusion matrix saved to {save_path}")

# Function to predict on a single image
def predict_single_image(model, image_path):
    """Predict on a single image and display/save results"""
    # Load image
    img_path = Path(image_path)
    if not img_path.exists():
        print(f"Image {image_path} not found!")
        return
    
    # Create output directory if it doesn't exist
    output_dir = Path("custom_predictions")
    output_dir.mkdir(exist_ok=True)
    
    # Define output paths
    output_image_path = output_dir / f"prediction_{img_path.name}"
    output_label_path = output_dir / f"prediction_{img_path.stem}.txt"
    
    # Make prediction
    print(f"Processing {img_path.name}...")
    result = predict_and_save(model, img_path, output_image_path, output_label_path, imgsz=640)
    
    # Print detected objects
    class_names = ['OxygenTank', 'NitrogenTank', 'FirstAidBox', 'FireAlarm', 'SafetySwitchPanel', 'EmergencyPhone', 'FireExtinguisher']
    print(f"\nDetected objects in {img_path.name}:")
    if len(result.boxes) > 0:
        for box in result.boxes:
            cls_id = int(box.cls[0])
            confidence = float(box.conf[0])
            class_name = class_names[cls_id] if cls_id < len(class_names) else f"Unknown({cls_id})"
            print(f"  - {class_name}: {confidence:.2f} confidence")
    else:
        print("  - No objects detected")
    
    print(f"\nPrediction image saved to: {output_image_path}")
    print(f"Prediction labels saved to: {output_label_path}")
    
    return result

if __name__ == '__main__': 
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='YOLO Safety Equipment Detection')
    parser.add_argument('--metrics-only', action='store_true', help='Calculate metrics only')
    parser.add_argument('--image', type=str, help='Path to a single image for prediction')
    args = parser.parse_args()

    this_dir = Path(__file__).parent
    os.chdir(this_dir)
    with open(this_dir / 'yolo_params.yaml', 'r') as file:
        data = yaml.safe_load(file)
        if 'test' in data and data['test'] is not None:
            # Use the correct absolute path
            images_dir = (this_dir / "hackathon2_test3" / "test3" / "images").resolve()
        else:
            print("No test field found in yolo_params.yaml, please add the test field with the path to the test images")
            exit()
    
    # Check if images are directly in the test directory
    if not images_dir.exists():
        print(f"Test directory {images_dir} does not exist")
        exit()

    # Check if the test directory contains images directly
    image_files = list(images_dir.glob("*.jpg")) + list(images_dir.glob("*.png"))
    if not image_files:
        print(f"No images found in {images_dir}")
        exit()
    
    # Load the YOLO model
    detect_path = this_dir / "runs" / "detect"
    train_folders = [f for f in os.listdir(detect_path) if os.path.isdir(detect_path / f) and f.startswith("train")]
    if len(train_folders) == 0:
        raise ValueError("No training folders found")
    
    # Automatically select the latest training folder
    # Sort by modification time and select the most recent one
    train_folders.sort(key=lambda x: os.path.getmtime(detect_path / x), reverse=True)
    idx = 0  # Select the most recent training folder
    
    model_path = detect_path / train_folders[idx] / "weights" / "best.pt"
    model = YOLO(model_path)
    
    # Handle single image prediction
    if args.image:
        predict_single_image(model, args.image)
        exit()
    
    # Directory with images
    output_dir = this_dir / "predictions" # Replace with the directory where you want to save predictions
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create images and labels subdirectories
    images_output_dir = output_dir / 'images'
    labels_output_dir = output_dir / 'labels'
    images_output_dir.mkdir(parents=True, exist_ok=True)
    labels_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Lists to store results for analysis
    all_results = []
    
    # Check if we want to run predictions or just calculate metrics
    if args.metrics_only:
        print("Skipping prediction generation, calculating metrics only...")
    else:
        # Process images in smaller batches to avoid memory issues
        batch_size = 5  # Reduced batch size to 5 images at a time
        total_images = len(image_files)
        
        print(f"Processing {total_images} images in batches of {batch_size}")
        
        # Iterate through the images in the directory
        for i, img_path in enumerate(image_files):
            if img_path.suffix not in ['.png', '.jpg']:
                continue
                
            output_path_img = images_output_dir / img_path.name  # Save image in 'images' folder
            output_path_txt = labels_output_dir / img_path.with_suffix('.txt').name  # Save label in 'labels' folder
            
            # Skip if already processed
            if output_path_img.exists() and output_path_txt.exists():
                print(f"Skipping {img_path.name} (already processed)")
                continue
                
            try:
                # Use smaller image size for memory efficiency
                result = predict_and_save(model, img_path, output_path_img, output_path_txt, imgsz=256)
                all_results.append(result)
                
                # Print progress
                if (i + 1) % 5 == 0 or (i + 1) == total_images:
                    print(f"Processed {i + 1}/{total_images} images")
                    
            except Exception as e:
                print(f"Error processing {img_path.name}: {e}")
                # Try to at least copy the original image to mark it as processed
                try:
                    orig_img = cv2.imread(str(img_path))
                    if orig_img is not None:
                        cv2.imwrite(str(output_path_img), orig_img)
                    # Create empty label file
                    with open(output_path_txt, 'w') as f:
                        pass  # Create empty file
                except Exception as fallback_error:
                    print(f"Fallback error for {img_path.name}: {fallback_error}")
                continue
        
        print(f"Predicted images saved in {images_output_dir}")
        print(f"Bounding box labels saved in {labels_output_dir}")
    
    data_yaml = this_dir / 'yolo_params.yaml'
    print(f"Model parameters saved in {data_yaml}")
    
    # Calculate and display metrics
    try:
        # Calculate and display metrics
        metrics = model.val(data=data_yaml, split="test")
        print(f"mAP@0.5: {metrics.box.map50:.4f}")
        print(f"mAP@0.5:0.95: {metrics.box.map:.4f}")
        print(f"Precision: {metrics.box.p:.4f}")
        print(f"Recall: {metrics.box.r:.4f}")
        print(f"F1-Score: {metrics.box.f1:.4f}")
        
        # Plot confusion matrix
        plot_confusion_matrix(model, data_yaml, str(output_dir / "confusion_matrix.png"))
        
        # Print class-wise metrics
        print("\nClass-wise metrics:")
        for i, class_name in enumerate(data['names']):
            print(f"{class_name}:")
            print(f"  mAP@0.5: {metrics.box.ap50[i]:.4f}")
            print(f"  Precision: {metrics.box.p[i]:.4f}")
            print(f"  Recall: {metrics.box.r[i]:.4f}")
            print(f"  F1-Score: {metrics.box.f1[i]:.4f}")
    except Exception as e:
        print(f"Error calculating metrics: {e}")