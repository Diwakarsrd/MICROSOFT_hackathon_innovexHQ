#!/usr/bin/env python3
"""
Real-time safety equipment detection using camera with flicker reduction
"""

import cv2
import torch
import numpy as np
from pathlib import Path
import yaml
import sys
from collections import deque

# Conditional import for ultralytics
try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except ImportError:
    YOLO = None
    ULTRALYTICS_AVAILABLE = False
    print("Warning: ultralytics not installed. Camera detection will not work.")

def load_model():
    """Load the trained YOLO model"""
    if not ULTRALYTICS_AVAILABLE or YOLO is None:
        raise RuntimeError("Ultralytics not available. Cannot load model.")
        
    # Look for model in the project root runs directory
    project_root = Path(__file__).parent.parent.parent
    detect_path = project_root / "runs" / "detect"
    
    # If not found, try the src/detection/runs directory (for backward compatibility)
    if not detect_path.exists():
        detect_path = Path(__file__).parent / "runs" / "detect"
    
    # Find the latest training folder
    if detect_path.exists():
        train_folders = [f for f in detect_path.iterdir() if f.is_dir() and f.name.startswith("train")]
        if train_folders:
            # Sort by modification time and select the most recent one
            train_folders.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            latest_train_folder = train_folders[0]
            model_path = latest_train_folder / "weights" / "best.pt"
            
            if model_path.exists():
                print(f"Loading model from: {model_path}")
                return YOLO(str(model_path))
    
    # Fallback to yolov8s.pt in project root
    fallback_path = project_root / "yolov8s.pt"
    if fallback_path.exists():
        print(f"Loading fallback model from: {fallback_path}")
        return YOLO(str(fallback_path))
    
    raise FileNotFoundError("No model file found. Please train a model first or provide yolov8s.pt")

def get_class_names():
    """Get class names from the configuration file"""
    # Look for config in project root
    project_root = Path(__file__).parent.parent.parent
    config_path = project_root / "src" / "utils" / "yolo_params.yaml"
    
    # Fallback to local directory
    if not config_path.exists():
        config_path = Path(__file__).parent.parent / "utils" / "yolo_params.yaml"
    
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        return config.get('names', [])
    except Exception as e:
        # Default class names
        return ['OxygenTank', 'NitrogenTank', 'FirstAidBox', 'FireAlarm', 
                'SafetySwitchPanel', 'EmergencyPhone', 'FireExtinguisher']

def safe_cv2_call(func_name, *args, **kwargs):
    """Safely call cv2 functions with error handling"""
    try:
        func = getattr(cv2, func_name)
        return func(*args, **kwargs)
    except AttributeError:
        # print(f"cv2.{func_name} not available")
        return None
    except Exception as e:
        # print(f"Error calling cv2.{func_name}: {e}")
        return None

def get_cv2_attribute(attr_name, default_value=0):
    """Safely get cv2 attributes"""
    try:
        return getattr(cv2, attr_name, default_value)
    except:
        return default_value

class DetectionTracker:
    """Class to track detections and reduce flickering using temporal consistency"""
    
    def __init__(self, max_history=5, iou_threshold=0.3):
        self.max_history = max_history
        self.iou_threshold = iou_threshold
        self.track_history = {}  # Track ID -> [detections]
        self.next_track_id = 0
        self.frame_count = 0
        
    def _calculate_iou(self, box1, box2):
        """Calculate Intersection over Union between two bounding boxes"""
        x1_1, y1_1, x2_1, y2_1 = box1
        x1_2, y1_2, x2_2, y2_2 = box2
        
        # Calculate intersection
        xi1 = max(x1_1, x1_2)
        yi1 = max(y1_1, y1_2)
        xi2 = min(x2_1, x2_2)
        yi2 = min(y2_1, y2_2)
        
        inter_width = max(0, xi2 - xi1)
        inter_height = max(0, yi2 - yi1)
        inter_area = inter_width * inter_height
        
        # Calculate union
        box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
        box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = box1_area + box2_area - inter_area
        
        if union_area == 0:
            return 0
            
        return inter_area / union_area
    
    def _match_detections(self, current_detections):
        """Match current detections with tracked objects"""
        matched_tracks = {}
        unmatched_detections = []
        unmatched_tracks = list(self.track_history.keys())
        
        # Match current detections with existing tracks
        for det in current_detections:
            box = (det['x1'], det['y1'], det['x2'], det['y2'])
            best_match = None
            best_iou = 0
            
            # Find best matching track
            for track_id in unmatched_tracks:
                if track_id in self.track_history and len(self.track_history[track_id]) > 0:
                    last_det = self.track_history[track_id][-1]
                    last_box = (last_det['x1'], last_det['y1'], last_det['x2'], last_det['y2'])
                    iou = self._calculate_iou(box, last_box)
                    
                    if iou > best_iou and iou > self.iou_threshold:
                        best_iou = iou
                        best_match = track_id
            
            if best_match is not None:
                matched_tracks[best_match] = det
                unmatched_tracks.remove(best_match)
            else:
                unmatched_detections.append(det)
        
        return matched_tracks, unmatched_detections, unmatched_tracks
    
    def update(self, detections):
        """Update tracker with new detections"""
        self.frame_count += 1
        
        # Match detections with existing tracks
        matched_tracks, unmatched_detections, unmatched_tracks = self._match_detections(detections)
        
        # Update matched tracks
        for track_id, det in matched_tracks.items():
            # Add frame information
            det['frame'] = self.frame_count
            self.track_history[track_id].append(det)
            # Keep only recent history
            if len(self.track_history[track_id]) > self.max_history:
                self.track_history[track_id].pop(0)
        
        # Remove unmatched tracks (they've disappeared)
        for track_id in list(unmatched_tracks):
            # Only remove if they haven't been seen for a few frames
            if track_id in self.track_history and len(self.track_history[track_id]) > 0:
                last_seen_frame = self.track_history[track_id][-1].get('frame', 0)
                if self.frame_count - last_seen_frame > 3:
                    if track_id in self.track_history:
                        del self.track_history[track_id]
        
        # Create new tracks for unmatched detections
        for det in unmatched_detections:
            det['frame'] = self.frame_count
            self.track_history[self.next_track_id] = [det]
            self.next_track_id += 1
        
        # Return stable detections (only show tracks that have been consistent)
        stable_detections = []
        for track_id, track_dets in self.track_history.items():
            # Only show detections if they've been seen in at least 2 frames
            if len(track_dets) >= 2:
                # Use the most recent detection
                stable_detections.append(track_dets[-1])
        
        return stable_detections

def draw_detections(frame, detections, class_names):
    """Draw improved bounding boxes and labels on the frame"""
    # Define colors for different classes (BGR format)
    colors = [
        (0, 255, 0),    # Green
        (255, 0, 0),    # Blue
        (0, 0, 255),    # Red
        (255, 255, 0),  # Cyan
        (255, 0, 255),  # Magenta
        (0, 255, 255),  # Yellow
        (128, 0, 128)   # Purple
    ]
    
    FONT_HERSHEY_SIMPLEX = get_cv2_attribute('FONT_HERSHEY_SIMPLEX')
    
    # Draw detections
    for det in detections:
        x1, y1, x2, y2 = det['x1'], det['y1'], det['x2'], det['y2']
        cls_id = det['class_id']
        class_name = det['class_name']
        confidence = det['confidence']
        
        # Select color based on class
        color = colors[cls_id % len(colors)] if cls_id < len(colors) else (0, 255, 0)
        
        # Draw bounding box with thicker lines for better visibility
        safe_cv2_call('rectangle', frame, (x1, y1), (x2, y2), color, 3)
        
        # Draw filled rectangle for label background
        label = f"{class_name}: {confidence:.2f}"
        text_size = safe_cv2_call('getTextSize', label, FONT_HERSHEY_SIMPLEX, 0.6, 2)
        if text_size:
            (text_width, text_height), baseline = text_size
            
            # Position label above the bounding box
            label_x = x1
            label_y = y1 - 10 if y1 - 10 > 10 else y1 + 10
            
            # Draw filled rectangle as background for better text visibility
            safe_cv2_call('rectangle', frame, (label_x, label_y - text_height - baseline), 
                         (label_x + text_width, label_y + baseline), 
                         color, -1)
            
            # Draw label text
            safe_cv2_call('putText', frame, label, (label_x, label_y), 
                         FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Draw corner rectangles for better bounding box visibility
            corner_length = min((x2-x1), (y2-y1)) // 4
            thickness = 2
            
            # Top-left corner
            safe_cv2_call('line', frame, (x1, y1), (x1 + corner_length, y1), color, thickness)
            safe_cv2_call('line', frame, (x1, y1), (x1, y1 + corner_length), color, thickness)
            
            # Top-right corner
            safe_cv2_call('line', frame, (x2, y1), (x2 - corner_length, y1), color, thickness)
            safe_cv2_call('line', frame, (x2, y1), (x2, y1 + corner_length), color, thickness)
            
            # Bottom-left corner
            safe_cv2_call('line', frame, (x1, y2), (x1 + corner_length, y2), color, thickness)
            safe_cv2_call('line', frame, (x1, y2), (x1, y2 - corner_length), color, thickness)
            
            # Bottom-right corner
            safe_cv2_call('line', frame, (x2, y2), (x2 - corner_length, y2), color, thickness)
            safe_cv2_call('line', frame, (x2, y2), (x2, y2 - corner_length), color, thickness)
    
    return frame

def test_camera():
    """Test if camera is accessible"""
    print("Testing camera access...")
    
    # Try different camera indices
    camera_indices = [0, 1, 2, 3]
    cap = None
    
    for idx in camera_indices:
        try:
            cap = safe_cv2_call('VideoCapture', idx)
            if cap and safe_cv2_call('isOpened', cap):
                print(f"Camera found at index {idx}")
                safe_cv2_call('release', cap)
                return idx
        except Exception as e:
            print(f"Error testing camera at index {idx}: {e}")
            if cap:
                safe_cv2_call('release', cap)
    
    print("No accessible camera found")
    return None

def main():
    """Main function to run real-time detection"""
    try:
        # Check if required packages are available
        if not ULTRALYTICS_AVAILABLE:
            print("Error: Ultralytics package not installed. Camera detection will not work.")
            return
            
        # Load model and class names
        print("Loading model...")
        model = load_model()
        class_names = get_class_names()
        print(f"Model loaded successfully with {len(class_names)} classes")
        print(f"Class names: {class_names}")
        
        # Test camera access
        camera_index = test_camera()
        if camera_index is None:
            print("Error: No accessible camera found")
            print("Alternative options:")
            print("1. Use the mobile app interface (mobile_app.py)")
            print("2. Test with individual images using predict.py --image <path>")
            return
        
        # Open camera
        print(f"Opening camera at index {camera_index}...")
        cap = safe_cv2_call('VideoCapture', camera_index)
        
        if not cap or not safe_cv2_call('isOpened', cap):
            print("Error: Could not open camera")
            return
        
        # Set camera properties for better performance (lower resolution to reduce flicker)
        try:
            CAP_PROP_FRAME_WIDTH = get_cv2_attribute('CAP_PROP_FRAME_WIDTH')
            CAP_PROP_FRAME_HEIGHT = get_cv2_attribute('CAP_PROP_FRAME_HEIGHT')
            
            # Use lower resolution to reduce flicker (as recommended)
            safe_cv2_call('set', cap, CAP_PROP_FRAME_WIDTH, 640)
            safe_cv2_call('set', cap, CAP_PROP_FRAME_HEIGHT, 480)
            
            # Set to auto exposure
            CAP_PROP_AUTO_EXPOSURE = get_cv2_attribute('CAP_PROP_AUTO_EXPOSURE')
            safe_cv2_call('set', cap, CAP_PROP_AUTO_EXPOSURE, 1)
        except Exception as e:
            print(f"Warning: Could not set camera properties: {e}")
        
        print("Camera opened successfully. Press 'q' to quit, 's' to save snapshot, '+' to increase confidence, '-' to decrease confidence.")
        
        frame_count = 0
        consecutive_failures = 0
        max_consecutive_failures = 10
        
        # Use lower confidence threshold to reduce flicker (as recommended)
        confidence_threshold = 0.25
        
        # Initialize detection tracker
        detection_tracker = DetectionTracker(max_history=5, iou_threshold=0.3)
        
        FONT_HERSHEY_SIMPLEX = get_cv2_attribute('FONT_HERSHEY_SIMPLEX')
        
        while True:
            read_result = safe_cv2_call('read', cap)
            if read_result is None:
                print("Error: Could not read frame from camera (read returned None)")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    print(f"Too many consecutive failures ({consecutive_failures}), exiting...")
                    break
                continue
                
            ret, frame = read_result
            if not ret:
                print("Error: Could not read frame from camera")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    print(f"Too many consecutive failures ({consecutive_failures}), exiting...")
                    break
                continue
            
            # Reset failure counter on successful frame read
            consecutive_failures = 0
            
            frame_count += 1
            
            # Run detection with lower confidence threshold
            detections = []
            if ULTRALYTICS_AVAILABLE and model is not None:
                try:
                    results = model(frame, conf=confidence_threshold, verbose=False)
                    result = results[0]
                    
                    # Extract detections
                    if result.boxes is not None and len(result.boxes) > 0:
                        for box in result.boxes:
                            # Get box coordinates
                            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                            
                            # Get class and confidence
                            cls_id = int(box.cls[0])
                            confidence = float(box.conf[0])
                            
                            # Get class name
                            class_name = class_names[cls_id] if cls_id < len(class_names) else f"Class {cls_id}"
                            
                            detections.append({
                                'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                'class_id': cls_id, 'class_name': class_name, 'confidence': confidence
                            })
                    
                    # Print detection info for debugging (only when detections change significantly)
                    if len(detections) > 0 and frame_count % 10 == 0:  # Print every 10 frames
                        print(f"Frame {frame_count}: Detected {len(detections)} objects (conf: {confidence_threshold:.2f})")
                        for i, det in enumerate(detections):
                            print(f"  {i+1}. {det['class_name']} ({det['confidence']:.2f})")
                            
                except Exception as e:
                    print(f"Error during detection: {e}")
            
            # Update tracker and get stable detections
            stable_detections = detection_tracker.update(detections)
            
            # Draw stable detections
            frame = draw_detections(frame, stable_detections, class_names)
            
            # Display detection count
            detection_count = len(stable_detections)
            
            try:
                safe_cv2_call('putText', frame, f"Detections: {detection_count}", (10, 30), 
                             FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # Display frame count and confidence threshold
                safe_cv2_call('putText', frame, f"Frame: {frame_count}", (10, 70), 
                             FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                safe_cv2_call('putText', frame, f"Conf: {confidence_threshold:.2f}", (10, 110), 
                             FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            except Exception as e:
                print(f"Error displaying text: {e}")
            
            # Display the frame
            safe_cv2_call('imshow', 'Safety Equipment Detection', frame)
            
            # Handle key presses
            key = 0xFF  # Default key value
            wait_key_result = safe_cv2_call('waitKey', 1)
            if wait_key_result is not None:
                key = wait_key_result & 0xFF
                
            if key == ord('q'):
                break
            elif key == ord('s'):
                # Save snapshot
                snapshot_path = f"snapshot_{frame_count}.jpg"
                safe_cv2_call('imwrite', snapshot_path, frame)
                print(f"Snapshot saved as {snapshot_path}")
            elif key == ord('+') or key == ord('='):
                # Increase confidence threshold
                confidence_threshold = min(0.8, confidence_threshold + 0.05)
                print(f"Confidence threshold increased to {confidence_threshold:.2f}")
            elif key == ord('-'):
                # Decrease confidence threshold
                confidence_threshold = max(0.1, confidence_threshold - 0.05)
                print(f"Confidence threshold decreased to {confidence_threshold:.2f}")
        
        # Clean up
        if cap:
            safe_cv2_call('release', cap)
        safe_cv2_call('destroyAllWindows')
        print("Camera closed. Exiting...")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return

if __name__ == "__main__":
    main()