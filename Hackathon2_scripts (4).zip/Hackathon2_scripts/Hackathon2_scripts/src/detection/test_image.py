#!/usr/bin/env python3
"""
Script to test the model with a specific image from the test dataset
"""

import cv2
from ultralytics import YOLO
from pathlib import Path
import os

def main():
    # Get the project directory
    this_dir = Path(__file__).parent
    
    # Find a test image
    test_images_dir = this_dir / "hackathon2_test3" / "test3" / "images"
    
    # Get the first image in the directory
    image_files = list(test_images_dir.glob("*.png")) + list(test_images_dir.glob("*.jpg"))
    
    if not image_files:
        print("No test images found!")
        return
    
    # Use the first image
    test_image_path = image_files[0]
    print(f"Testing with image: {test_image_path.name}")
    
    # Load the model
    detect_path = this_dir / "runs" / "detect"
    train_folders = [f for f in os.listdir(detect_path) if os.path.isdir(detect_path / f) and f.startswith("train")]
    
    if len(train_folders) == 0:
        print("No trained model found!")
        return
    
    # Sort by modification time and select the most recent one
    train_folders.sort(key=lambda x: os.path.getmtime(detect_path / x), reverse=True)
    model_path = detect_path / train_folders[0] / "weights" / "best.pt"
    
    if not model_path.exists():
        print(f"Model file not found at {model_path}")
        return
    
    print("Loading model...")
    model = YOLO(str(model_path))
    print("Model loaded successfully!")
    
    # Process the image
    print(f"Processing image: {test_image_path}")
    results = model.predict(source=str(test_image_path), conf=0.25, save=True, save_txt=True, project="test_results")
    
    print("Detection results:")
    result = results[0]
    
    # Class names
    class_names = ['OxygenTank', 'NitrogenTank', 'FirstAidBox', 'FireAlarm', 'SafetySwitchPanel', 'EmergencyPhone', 'FireExtinguisher']
    
    if len(result.boxes) > 0:
        for i, box in enumerate(result.boxes):
            cls_id = int(box.cls[0])
            confidence = float(box.conf[0])
            class_name = class_names[cls_id] if cls_id < len(class_names) else f"Class {cls_id}"
            print(f"  {i+1}. {class_name}: {confidence:.2f} confidence")
    else:
        print("  No objects detected")
    
    print(f"Results saved in 'test_results' directory")

if __name__ == "__main__":
    main()