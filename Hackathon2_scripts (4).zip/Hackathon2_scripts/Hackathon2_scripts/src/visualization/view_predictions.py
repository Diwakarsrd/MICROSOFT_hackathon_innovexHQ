#!/usr/bin/env python3
"""
Script to view predictions on test images
"""

import cv2
import random
from pathlib import Path

def view_random_predictions():
    """Display random predictions from the test set"""
    this_dir = Path(__file__).parent
    images_dir = this_dir / "predictions" / "images"
    
    # Get all prediction images
    image_files = list(images_dir.glob("*.png")) + list(images_dir.glob("*.jpg"))
    
    if not image_files:
        print("No prediction images found!")
        return
    
    # Select and display 5 random images
    print(f"Found {len(image_files)} prediction images")
    print("Displaying 5 random predictions. Press any key to continue to next image, 'q' to quit.")
    
    selected_images = random.sample(image_files, min(5, len(image_files)))
    
    for img_path in selected_images:
        print(f"Displaying: {img_path.name}")
        img = cv2.imread(str(img_path))
        if img is not None:
            # Resize for better display if too large
            h, w = img.shape[:2]
            if h > 800 or w > 1200:
                scale = min(800/h, 1200/w)
                img = cv2.resize(img, (int(w*scale), int(h*scale)))
            
            cv2.imshow("Prediction", img)
            key = cv2.waitKey(0) & 0xFF
            if key == ord('q'):
                break
        else:
            print(f"Could not load image: {img_path}")
    
    cv2.destroyAllWindows()

if __name__ == "__main__":
    view_random_predictions()