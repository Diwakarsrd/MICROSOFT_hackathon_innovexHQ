import os
import cv2 # type: ignore


class YoloVisualizer:
    MODE_TRAIN = 0
    MODE_VAL = 1
    MODE_TEST = 2
    
    def __init__(self, base_path):
        self.base_path = base_path
        classes_file = os.path.join(base_path, "classes.txt")
        with open(classes_file, "r") as f:
            self.classes = f.read().splitlines()
        self.classes = {i: c for i, c in enumerate(self.classes)}
        self.set_mode(YoloVisualizer.MODE_TRAIN)
    
    def set_mode(self, mode=MODE_TRAIN):
        if mode == self.MODE_TRAIN:
            self.images_folder = os.path.join(self.base_path, "..", "hackathon2_train_1", "train_1", "train1", "images")
            self.labels_folder = os.path.join(self.base_path, "..", "hackathon2_train_1", "train_1", "train1", "labels")
        elif mode == self.MODE_VAL:
            self.images_folder = os.path.join(self.base_path, "..", "hackathon2_train_1", "train_1", "val1", "images")
            self.labels_folder = os.path.join(self.base_path, "..", "hackathon2_train_1", "train_1", "val1", "labels")
        else:  # MODE_TEST
            self.images_folder = os.path.join(self.base_path, "..", "hackathon2_test3", "test3", "images")
            self.labels_folder = os.path.join(self.base_path, "..", "hackathon2_test3", "test3", "labels")
            
        # Check if folders exist
        if not os.path.exists(self.images_folder):
            print(f"Images folder does not exist: {self.images_folder}")
            return
        if not os.path.exists(self.labels_folder):
            print(f"Labels folder does not exist: {self.labels_folder}")
            return
            
        self.image_names = sorted([f for f in os.listdir(self.images_folder) if f.endswith(('.png', '.jpg'))])
        self.label_names = sorted([f for f in os.listdir(self.labels_folder) if f.endswith('.txt')])
        
        self.num_images = len(self.image_names)
        num_labels = len(self.label_names)
        
        if self.num_images == 0:
            print(f"No images found in {self.images_folder}")
            return
            
        print(f"Loaded {self.num_images} images and {num_labels} labels")
        self.frame_index = 0

    def next_frame(self):
        self.frame_index += 1
        if self.frame_index >= self.num_images:
            self.frame_index = 0
        elif self.frame_index < 0:
            self.frame_index = self.num_images - 1

    def previous_frame(self):
        self.frame_index -= 1
        if self.frame_index >= self.num_images:
            self.frame_index = 0
        elif self.frame_index < 0:
            self.frame_index = self.num_images - 1
    
    def seek_frame(self, idx):
        if self.num_images == 0:
            return None
            
        image_file = os.path.join(self.images_folder, self.image_names[idx])
        # Get corresponding label file name (same as image but with .txt extension)
        label_file_name = os.path.splitext(self.image_names[idx])[0] + ".txt"
        label_file = os.path.join(self.labels_folder, label_file_name)
        
        # Check if files exist
        if not os.path.exists(image_file):
            print(f"Image file not found: {image_file}")
            return None
            
        # Read image
        image = cv2.imread(image_file) # type: ignore
        if image is None:
            print(f"Could not read image: {image_file}")
            return None
            
        # Draw bounding boxes if label file exists
        if os.path.exists(label_file):
            with open(label_file, "r") as f:
                lines = f.read().splitlines()
            for line in lines:
                parts = line.split()
                if len(parts) >= 5:
                    class_index, x, y, w, h = map(float, parts[:5])
                    cx = int(x * image.shape[1])
                    cy = int(y * image.shape[0])
                    w = int(w * image.shape[1])
                    h = int(h * image.shape[0])
                    x = cx - w // 2
                    y = cy - h // 2
                    # Draw rectangle and text
                    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2) # type: ignore
                    if int(class_index) in self.classes:
                        cv2.putText(image, self.classes[int(class_index)], (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2) # type: ignore
        else:
            print(f"Label file not found: {label_file}")
            
        return image

    def run(self):
        if self.num_images == 0:
            print("No images to display")
            return
            
        while True:
            frame = self.seek_frame(self.frame_index)
            if frame is not None:
                frame = cv2.resize(frame, (640, 480)) # type: ignore
                mode_name = ["TRAIN", "VAL", "TEST"][self.mode] if hasattr(self, 'mode') else "TRAIN"
                cv2.imshow(f"Yolo Visualizer - Mode: {mode_name}", frame) # type: ignore
            else:
                print("Could not load frame")
                
            key = cv2.waitKey(0) & 0xFF # type: ignore
            if key == ord('q') or key == 27 or key == -1:  # q, ESC, or window closed
                break
            elif key == ord('d'):
                self.next_frame()
            elif key == ord('a'):
                self.previous_frame()
            elif key == ord('t'):
                self.set_mode(YoloVisualizer.MODE_TRAIN)
                self.mode = YoloVisualizer.MODE_TRAIN
            elif key == ord('v'):
                self.set_mode(YoloVisualizer.MODE_VAL)
                self.mode = YoloVisualizer.MODE_VAL
            elif key == ord('e'):
                self.set_mode(YoloVisualizer.MODE_TEST)
                self.mode = YoloVisualizer.MODE_TEST
        cv2.destroyAllWindows() # type: ignore


if __name__ == "__main__":
    vis = YoloVisualizer(os.path.dirname(__file__))
    vis.run()